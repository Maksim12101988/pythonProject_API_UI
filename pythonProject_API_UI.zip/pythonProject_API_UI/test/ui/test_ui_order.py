import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


@pytest.fixture(scope="function")
def driver():
    from webdriver_manager.chrome import ChromeDriverManager
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service)
    yield driver
    driver.quit()


@pytest.mark.asyncio
async def test_full_order_flow(driver):
    # Вход в систему
    login_url = "https://www.automationexercise.com/login/"
    driver.get(login_url)
    username_input = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, "email")))
    username_input.send_keys("test@example.com")
    password_input = driver.find_element(By.NAME, "password")
    password_input.send_keys("password123")
    login_button = driver.find_element(By.XPATH, "//button[@id='submit-login']")
    login_button.click()

    # Добавление товара в корзину
    product_url = "https://www.automationexercise.com/products/"
    driver.get(product_url)
    add_to_cart_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, "//a[@href='/cart']")))
    add_to_cart_button.click()

    # Переход в корзину
    cart_url = "https://www.automationexercise.com/cart/"
    driver.get(cart_url)

    # Подтверждение покупки
    checkout_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, "//a[@href='/checkout']")))
    checkout_button.click()

    # Ввод данных карты
    card_details_url = "https://www.automationexercise.com/payment"
    driver.get(card_details_url)

    name_input = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, "cardname")))
    name_input.send_keys("Test Name")

    card_number_input = driver.find_element(By.NAME, "cardnumber")
    card_number_input.send_keys("4242424242424242")  # Пример номера карты

    cvc_input = driver.find_element(By.NAME, "cvc")
    cvc_input.send_keys("123")

    expiry_month_input = driver.find_element(By.NAME, "expmonth")
    expiry_month_input.send_keys("12")

    expiry_year_input = driver.find_element(By.NAME, "expyear")
    expiry_year_input.send_keys("2025")

    pay_and_confirm_order_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//button[@text()='Pay and Confirm Order']"
    )))
