import requests
from typing import Dict, Any
import asyncio

class APIClient:
    BASE_URL = "https://automationexercise.com/api"

    async def create_user(self, **kwargs) -> requests.Response:
        url = f"{self.BASE_URL}/createAccount"
        data = {
            "name": kwargs.get("name"),
            "email": kwargs.get("email"),
            "password": kwargs.get("password"),
            "title": kwargs.get("title"),
            "birth_date": kwargs.get("birth_date"),
            "birth_month": kwargs.get("birth_month"),
            "birth_year": kwargs.get("birth_year"),
            "firstname": kwargs.get("firstname"),
            "lastname": kwargs.get("lastname"),
            "company": kwargs.get("company"),
            "address1": kwargs.get("address1"),
            "address2": kwargs.get("address2"),
            "country": kwargs.get("country"),
            "zipcode": kwargs.get("zipcode"),
            "state": kwargs.get("state"),
            "city": kwargs.get("city"),
            "mobile_number": kwargs.get("mobile_number")
        }
        return self.session.post(url, json=data)

    async def delete_user(self, email: str) -> requests.Response:
        url = f"{self.BASE_URL}/deleteAccount"
        data = {"email": email}
        return self.session.delete(url, json=data)
