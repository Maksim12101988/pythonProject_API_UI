import pytest
from api_client import APIClient
import asyncio


@pytest.fixture(scope="function")
async def api_client():
    client = APIClient()
    yield client


@pytest.mark.asyncio
async def test_user_creation(api_client):
    email = f"user_{pytest.currentfixture.name}@example.com"

    # Создание пользователя
    response = await api_client.create_user(
        name="Test User",
        email=email,
        password="password123",
        title="Mr",
        birth_date="1990-01-01",
        birth_month="January",
        birth_year=1990,
        firstname="John",
        lastname="Doe",
        company="Test Company",
        address1="123 Test St",
        address2="Apt 4B",
        country="United States",
        zipcode="12345",
        state="California",
        city="San Francisco",
        mobile_number="1234567890"
    )
    assert response.status_code == 201, f"Failed to create user: {response.text}"

    # Проверка созданного пользователя
    get_user_response = await api_client.get_user(email)
    assert get_user_response.status_code == 200, f"Failed to get created user: {get_user_response.text}"
    data = get_user_response.json()
    assert data["response"]["email"] == email, f"Created user email does not match: {data['response']['email']}"


@pytest.mark.asyncio
async def test_user_deletion(api_client):
    # Создание пользователя (используем фикстуру из предыдущего теста)
    response = await api_client.create_user(
        name="Test User",
        email=f"user_delete@example.com",
        password="password123",
        title="Mr",
        birth_date="1990-01-01",
        birth_month="January",
        birth_year=1990,
        firstname="John",
        lastname="Doe",
        company="Test Company",
        address1="123 Test St",
        address2="Apt 4B",
        country="United States",
        zipcode="12345",
        state="California",
        city="San Francisco",
        mobile_number="1234567890"
    )
    assert response.status_code == 201, f"Failed to create user: {response.text}"

    # Удаление пользователя
    delete_response = await api_client.delete_user(email="user_delete@example.com")
    assert delete_response.status_code == 200, f"Failed to delete user: {delete_response.text}"


@pytest.mark.asyncio
async def test_user_retrieval(api_client):
    email = "test@example.com"
    response = await api_client.get_user(email)
    assert response.status_code == 200, f"Failed to get user: {response.text}"
    data = response.json()
    assert data["response"]["email"] == email, f"Retrieved user email does not match: {data['response']['email']}"
